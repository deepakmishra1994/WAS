package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.ReportGenerator;
import beans.Users;
import datalayer.UserOperations;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getParameter("btnLogin")!=null)
        {           
            String userName=request.getParameter("txtId");
            String password=request.getParameter("txtPassword");
            datalayer.UserOperations u=new UserOperations();
            beans.Users usr=u.authenticate(userName, password);
            if(usr.getId()>0)
            {
            	request.getSession().setAttribute("session_id",usr.getId());
            	response.sendRedirect("Configure.jsp?userName="+usr.getUserName());
            }
            else
            	response.sendRedirect("Login.jsp?flag1=1");            	
        }
		if(request.getParameter("btnSave")!=null)
		{
			int id=Integer.parseInt(request.getSession().getAttribute("session_id").toString());
			String usernameIBM=request.getParameter("IBMId");
			String passwordIBM=request.getParameter("IBMpassword");		
			String auto_Level=request.getParameter("rbtLevel");
			String path=request.getParameter("txtPath");
			int index=path.lastIndexOf("\\");
			String folder_path=path.substring(0,index);	
			datalayer.UserOperations uo=new UserOperations();			
			int ret=uo.saveData(id,usernameIBM,passwordIBM,auto_Level,folder_path);
			if(ret==1)
			{
				response.sendRedirect("Configure.jsp?saved=1");
			}
			else
			{
				response.sendRedirect("Configure.jsp?saved_no=1");
			}
			//System.out.println(folder_path);
			
			//beans.ReportGenerator r=new ReportGenerator();
			//r.generatereport(path);
		}
		if(request.getParameter("btnBegin")!=null)
		{
			
			response.sendRedirect("Applications.jsp");
		}
		if(request.getParameter("btnEvaluate")!=null)
		{
			String app_path=request.getParameter("app_Names");
			//System.out.println(appName);
			beans.ReportGenerator r=new ReportGenerator();
			r.generatereport(app_path);		
		}
		if(request.getParameter("btnPush")!=null)
		{
			String app_path=request.getParameter("app_Names");	
			int index=app_path.lastIndexOf("\\");
			String app_Name=app_path.substring(index+1);
			System.out.print(app_Name);
		}
		doGet(request, response);
	}

}
