package servlet;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.ReportGenerator;
import beans.Users;
import datalayer.UserOperations;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getParameter("btnLogin")!=null)
        {           
            String userName=request.getParameter("txtId");
            String password=request.getParameter("txtPassword");
            datalayer.UserOperations u=new UserOperations();
            beans.Users usr=u.authenticate(userName, password);
            if(usr.getId()>0)
            {
            	request.getSession().setAttribute("session_id",usr.getId());
            	response.sendRedirect("Configure.jsp");
            }
            else
            	response.sendRedirect("Login.jsp?flag1=1");            	
        }
		if(request.getParameter("btnSave")!=null)
		{
			int id=Integer.parseInt(request.getSession().getAttribute("session_id").toString());
			String usernameIBM=request.getParameter("IBMId");
			String passwordIBM=request.getParameter("IBMpassword");		
			String auto_Level=request.getParameter("rbtLevel");
			String path=request.getParameter("txtPath");
			int index=path.lastIndexOf("\\");
			String folder_path=path.substring(0,index);	
			datalayer.UserOperations uo=new UserOperations();			
			int ret=uo.saveData(id,usernameIBM,passwordIBM,auto_Level,folder_path);						
			if(ret==1)
			{
				response.sendRedirect("Configure.jsp?saved=1");
			}
			else
			{
				response.sendRedirect("Configure.jsp?saved_no=1");
			}
			//System.out.println(folder_path);
			
			//beans.ReportGenerator r=new ReportGenerator();
			//r.generatereport(path);
		}
		if(request.getParameter("btnBegin")!=null)
		{
			int id=Integer.parseInt(request.getSession().getAttribute("session_id").toString());
			datalayer.UserOperations u=new UserOperations();
			beans.Users usr=u.getData(id);
			if(usr.getAutomationLevel().equals("Fully"))
			{
				response.sendRedirect("Applications.jsp?aL="+usr.getAutomationLevel());
			}
			else if(usr.getAutomationLevel().equals("Partial")) 
			{
				response.sendRedirect("Applications.jsp?aL="+usr.getAutomationLevel());
			}			
		}
		if(request.getParameter("btnEvaluate")!=null)
		{			
			String app_path=request.getParameter("app_Names");
			String type_of_report="evaluate";
			String source_app_server=request.getParameter("sServer");
			String target_app_server=request.getParameter("tServer");
			String source_java=request.getParameter("sJava");
			String target_java=request.getParameter("tJava");
			//System.out.println(appName);
			beans.ReportGenerator r=new ReportGenerator();
			r.generatereport(app_path,type_of_report,source_app_server,target_app_server,source_java,target_java);		
		}
		if(request.getParameter("btnAnalyze")!=null)
		{
			String app_path=request.getParameter("app_Names");
			String type_of_report="analyze";
			String source_app_server=request.getParameter("sServer");
			String target_app_server=request.getParameter("tServer");
			String source_java=request.getParameter("sJava");
			String target_java=request.getParameter("tJava");			
			beans.ReportGenerator r=new ReportGenerator();
			r.generatereport(app_path,type_of_report,source_app_server,target_app_server,source_java,target_java);			
		}
		if(request.getParameter("btnMigrate")!=null)
		{
			String app_path=request.getParameter("app_Names");
			String type_of_report="all";
			String source_app_server=request.getParameter("sServer");
			String target_app_server=request.getParameter("tServer");
			String source_java=request.getParameter("sJava");
			String target_java=request.getParameter("tJava");			
			beans.ReportGenerator r=new ReportGenerator();
			r.generatereport(app_path,type_of_report,source_app_server,target_app_server,source_java,target_java);
		}
		if(request.getParameter("btnPush")!=null)
		{
			String app_path=request.getParameter("app_Names");	
			int index=app_path.lastIndexOf("\\");
			String app_Name=app_path.substring(index+1);
			System.out.print(app_Name);
		}
		doGet(request, response);
	}

}
