package beans;
import java.io.File;
public class ReportGenerator
{
    public void generatereport(String path)
    {
        try
        { 
        	//C:\\Users\\DE393632\\Desktop\\
			File batchFile = new File("test.bat");
										
			final ProcessBuilder processBuilder = new ProcessBuilder(batchFile.getAbsolutePath(),path);
			//ProcessBuilder pb = new ProcessBuilder(batchFile.getAbsolutePath(), name);
			
			//Process process = pb.start();
			
			final Process process = processBuilder.start();
			final int exitStatus = process.waitFor();
			System.out.println("Processed finished with status: " + exitStatus);
									        
        }
        catch (Exception e)
        {            
            e.printStackTrace();
        }
    }
}