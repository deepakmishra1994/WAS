package beans;
import java.io.File;
public class ReportGenerator
{
    public void generatereport(String app_path,String type_of_report,String source_app_server,String target_app_server,String source_java,String target_java)
    {
        try
        { 
        	//C:\\Users\\DE393632\\Desktop\\        
			File batchFile = new File("test.bat");
										
			final ProcessBuilder processBuilder = new ProcessBuilder(batchFile.getAbsolutePath(),app_path,type_of_report,source_app_server,target_app_server,source_java,target_java);
			//ProcessBuilder pb = new ProcessBuilder(batchFile.getAbsolutePath(), name);
			
			//Process process = pb.start();
			
			final Process process = processBuilder.start();
			final int exitStatus = process.waitFor();
			System.out.println("Processed finished with status: " + exitStatus);
									        
        }
        catch (Exception e)
        {            
            e.printStackTrace();
        }
    }
}