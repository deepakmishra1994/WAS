package datalayer;
import java.sql.*;
public class DBOperations 
{
	private static Connection con=null;
	 public static Connection getConnection()
	    {
	        if(con==null)
	        {
	            try
	            {
	                Class.forName("com.mysql.jdbc.Driver");
	                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/WASdb","root","mysql");	                
	             }	            
	            catch(Exception ex)
	            {
	            
	            }
	        
	        }
	        return con;	        
	    }
}
