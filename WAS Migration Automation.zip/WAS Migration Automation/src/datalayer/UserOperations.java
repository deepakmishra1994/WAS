package datalayer;
import beans.Users;

import java.io.File;
import java.sql.*;

public class UserOperations 
{
	private Connection con =null;
	public UserOperations()
	{
		con=DBOperations.getConnection();		
	}
	
	public beans.Users authenticate(String userName,String password)
	{
		beans.Users usr=new Users();
		try
		{					
			PreparedStatement ps=con.prepareStatement("select * from WASUsers where username=? and password=?");
		    ps.setString(1,userName);
		    ps.setString(2,password);
		    ResultSet rs=ps.executeQuery();  
                boolean ret=rs.next();
                if(ret)
                {
                    usr.setId(rs.getInt("id"));
                    usr.setUserName(rs.getString("username"));
                    usr.setPassword(rs.getString("password"));
                }
        }
        catch(Exception e)
		{
        	e.printStackTrace();
			System.out.println(e);			
		}		
        return usr;
	}
	public int saveData(int id,String usrName,String pswrd,String auto_level,String folder_path)
	{
		int i=0;
		try
		{					
			PreparedStatement ps=con.prepareStatement("update WASUsers set IBMUsername=?,IBMpassword=?,automationLevel=?,folderpath=? where id=?");
		    ps.setString(1,usrName);
		    ps.setString(2,pswrd);
		    ps.setString(3,auto_level);
		    ps.setString(4,folder_path);
		    ps.setInt(5,id);
		    i=ps.executeUpdate();
		    return i;
        }
        catch(Exception e)
		{
        	e.printStackTrace();
			System.out.println(e);				
		}	
		return i;
	}	
	public beans.Users getData(int id)
    {
        beans.Users u=new Users();
        try
        {
            PreparedStatement ps=con.prepareStatement("Select * from WASUsers where id=?");
            ps.setInt(1,id);
            
            
            ResultSet rs=ps.executeQuery();
            boolean ret=rs.next();
            if(ret)
            {
            	u.setId(id);
            	u.setUserName(rs.getString("username"));
            	u.setPassword(rs.getString("password"));
            	u.setIBMusername(rs.getString("IBMusername"));
            	u.setIBMpassword(rs.getString("IBMpassword"));
            	u.setAutomationLevel(rs.getString("automationLevel"));
            	u.setFolderPath(rs.getString("folderpath"));
            }
            rs.close();
        }
        catch(Exception ex)
        {
            
        }
        return u;
}
}
